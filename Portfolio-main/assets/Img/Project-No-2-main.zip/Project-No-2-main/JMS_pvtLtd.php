<html>
      <head>
          <body> <h1>JMS Banking Pvt Ltd</h1>  </tilte>
       </title>
<body>
    <img style="margin-right:70px;height:70px;width:150px"  src="jms.png"/>
    <div style="float:right;margin=right:20px;width:  900px;border-radius: 10px; backgroundc=color:  #28455e;height: 50px;">
        <li style="list-style-type:none;margin-top:10px;  margin-left: 75px;">
            <li style="display:inline;padding:40px"><a style="color:yellow;" href="login.php">Home</a></li>
            <li style="display:inline;padding:40px"><a style="color:red;" href="Customer_login.php">Services</a></li>
            <li style="display:inline;padding:40px"><a style="color:green;" href="credit_card.php">Loans</a></li>
            <li style="display:inline;padding:40px"><a style="color:blue;" href="About.php">About Us</a></li>
            <li style="display:inline;padding:40px"><a style="color:black;" href="Contact_Us.php">Contact Us</a></li>
            <li style="display:inline;padding:40px"><a style="color:black;" href="Social_media.php">Social media</a></li>
        </li>
    </div>
</p>
<div style="height:100px;width:   100%;"   background-color:  #28455e;></div>
<img src="https://media.istockphoto.com/photos/bank-building-picture-id640267784?k=20&m=640267784&s=612x612&w=0&h=3j1dH5Ty9qAq69ciYra7oBOn4C3zxyzMCgg2Hdo8ang=" alt="" style="width:100%;">
</body>
</html>
   
   